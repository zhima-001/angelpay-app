<?php
$uid = "xx";      //商户号【不用动】
$uidkey = "xxxx";  //商户密钥【不用动】
$pay_url = "https://tianshipay.azkumqwzrb.top/submit.php";  //天使下单地址【不用动】
?>