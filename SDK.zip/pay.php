<?php
header('Content-Type: application/json');
include_once('config.php');
function send_post($url, $post_data)
{

        $postdata = http_build_query($post_data);
        $options = array(
            'http' => array(
                'method' => 'POST',
                'header' => 'Content-type:application/x-www-form-urlencoded',
                'content' => $postdata,
                'timeout' => 15 * 60 // 超时时间（单位:s）
            )
        );
        $context = stream_context_create($options);
        $result = file_get_contents($url, false, $context);

        return $result;
 }
// 检查是否通过 POST 方法提交表单
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 获取用户提交的数据
    $amount = isset($_POST['amount']) ? $_POST['amount'] : '';
    $paymentMethod = isset($_POST['payment']) ? $_POST['payment'] : '';
    $note = isset($_POST['note']) ? $_POST['note'] : '';

    // 对提交的数据进行简单处理或验证
    if (empty($amount) || empty($paymentMethod)) {
          $response = array(
                    'code' => 201,
                    'msg' => '金额和支付方式为必填项，请重新填写。'
           );
          echo json_encode($response);
          exit;
     
    } else {
            //构建支付：
            $trade_no = date("YmdHis").rand(1000,9999).$uid;
            $arr = array(
                'pid' => $uid,
                'type' => $paymentMethod,
                'out_trade_no' => $trade_no,
                'notify_url'=>"https://baidu.com",
                'return_url'=>"https://baidu.com",
                'name' => $trade_no,
                'money' => $amount,
            );
            ksort($arr);
            reset($arr);
           
            $arg  = "";
            foreach ($arr as $key=>$val) {
                $arg .= $key."=".$val."&";
            }
            //去掉最后一个&字符
            $arg = substr($arg,0,-1);
            $sign = md5($arg.$uidkey);
            $arr['sign']=$sign;
            $arr['sign_type']="MD5";  
            $arr['request_method']="JSON";
            $get_data =json_decode(trim(send_post($pay_url, $arr)),true);
           // var_dump($get_data['pay_url']);
            // if ($amount > 0 && !empty($payment)) {
            //     // 模拟支付成功并返回支付链接
            //     $response = array(
            //         'code' => 200,
            //         'pay_url' => 'https://example.com/pay?amount=' . $amount . '&payment=' . $payment
            //     );
            // } else {
            //     // 模拟支付失败
            //     $response = array(
            //         'code' => 201,
            //         'msg' => '支付失败，金额或支付方式错误'
            //     );
            // }
            // $response = array(
            //         'code' => 201,
            //         'msg' => '支付失败，金额或支付方式错误'
            // );
            // 返回 JSON 格式的响应
           
            echo json_encode($get_data);
            exit;
        
        
        // 打印提交的表单数据
        // echo "<h1>支付信息</h1>";
        // echo "<p>支付金额：¥" . htmlspecialchars($amount) . "</p>";
        // echo "<p>支付方式：" . htmlspecialchars($paymentMethod) . "</p>";
        // echo "<p>备注：" . htmlspecialchars($note) . "</p>";

        // 如果需要，可以在这里调用你的接口逻辑或将数据保存到数据库
    }
} else {
    // 如果不是 POST 请求，提示错误
     $response = array(
                    'code' => 201,
                    'msg' => '无效的请求方式，请通过支付页面提交数据。'
           );
          echo json_encode($response);
          exit;
   
}
?>
