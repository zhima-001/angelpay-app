<?php

if(!defined('IN_PLUGIN'))exit();
file_put_contents("./haoyunpay.txt","==========================". PHP_EOL,FILE_APPEND);
file_put_contents("./haoyunpay.txt",date("Y-m-d H:i:s")." 上游回调信息: ".json_encode($_POST). PHP_EOL,FILE_APPEND);
$mishi = $_POST['mishi'];


require 'pay/config.php';




file_put_contents('./demo.txt',file_get_contents('php://input'));

//$info = file_get_contents('php://input');
$_REQUEST = json_decode(file_get_contents('php://input'),true);

//flag = verify($_POST,$md5Key, $ptKey);
$flag = false;

//{"data":{"amount":"100.00","orderNo":"2022031708592016395","transactionalNumber":"LA1647478761318632695"},"message":"成功","sign":"c06cfcb5f9057b4e4501cf5a40f18f54","success":true}
$returnArray = array( // 返回字段
            "amount" => $_REQUEST['data']["amount"], // 商户ID
            "orderNo" =>  $_REQUEST['data']["orderNo"], // 订单号
            "transactionalNumber" =>  $_REQUEST['data']["transactionalNumber"], // 交易金额
       
        );
       
        ksort($returnArray); 
        reset($returnArray);
        $md5str = "";
        foreach ($returnArray as $key => $val) {
            $md5str = $md5str . $key . "=" . $val . "&";
        }
        $sign = strtolower(md5($md5str . "key=" . $md5key));
        if ($sign == $_REQUEST["sign"]) {
            if ($_REQUEST["success"]) {
            
                   $flag = true;
            }
        }else {
            exit("签名异常！");
        }




$returnArray['name'] ='盲僧支付';
$out_trade_no = daddslashes($returnArray["orderNo"]);
//日志开始
	$shuju = $returnArray;
	$Money =$_REQUEST['data']["amount"];
	$shuju1 = json_encode($shuju,true);
	$DB->exec("INSERT INTO `pre_notify_rizhi` (`content`,`addtime`, `jine`,`zt`) VALUES (:content,:addtime, :jine,:zt)", [':content'=>$shuju1,':addtime'=>time(),':jine'=>$Money,':zt'=>'ok']);

if($flag){
    //处理逻辑

	$orderAmt = $Money;
	$date = date("Y-m-d H:i:s",time()); 
	//	var_dump($date);
	//exit();

	$trade_no = daddslashes($returnArray["transactionalNumber"]);
	//echo "update `pre_order` set `api_trade_no` ='$trade_no',`endtime` ='$date',`date` =NOW(),`randmoney` = $orderAmt where `trade_no`='$out_trade_no'";
		if($DB->exec("update `pre_order` set `status` ='1' where `trade_no`='$out_trade_no'")){
			//echo "$orderAmt";
				$DB->exec("update `pre_order` set `api_trade_no` ='$trade_no',`endtime` ='$date',`date` =NOW(),`randmoney` = $orderAmt where `trade_no`='$out_trade_no'");
				$DB->exec("update `pay_rand` set `status` ='1',`orderno` ='0',`url` = '0', `reorder` = '' where `orderno`='$out_trade_no'");
				file_put_contents("./haoyunpay.txt",date("Y-m-d H:i:s")." 准备处理订单信息: ".json_encode($order). PHP_EOL,FILE_APPEND);
				file_put_contents("./haoyunpay.txt","==========================". PHP_EOL,FILE_APPEND);
				processOrder($order);
			}
    exit('ok');
}
file_put_contents('./shibai.txt',file_get_contents('php://input'));
exit('sign error');

?>
