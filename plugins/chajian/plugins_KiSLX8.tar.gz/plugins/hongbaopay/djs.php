<?php 
	$rand= $DB->getRow("SELECT * FROM pre_hongbao WHERE trade_no = '".TRADE_NO."' LIMIT 1");

	$djs=300-time()+($rand["addtime"]);

$arr['djs'] = $djs;
echo json_encode($arr);
?>