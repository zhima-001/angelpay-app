<?php
if(!defined('IN_PLUGIN'))exit();
include 'function.php';
//require_once(PAY_ROOT."inc/epay_submit.class.php");
$order= $DB->getRow("SELECT * FROM pre_order WHERE trade_no = '".$trade_no."'");
$erweima = erweima($channel,$order);//二维码金额
//var_dump($erweima);exit;
if($order["money"]%2!=0){
    echo "金额错误";exit;
}
if($order['money']<4)
{
	echo '最少支付4元';exit;
}

$suiji1 = rand(10000,99999);
if($order['sjm']!="")
{
	
}
else
{
	$DB->exec("update `pre_order` set `sjm` ='$suiji1' where `trade_no`='$trade_no'");
	
}

$time = time()-300;//倒计时时间5分钟。
//require_once(PAY_ROOT."inc/epay_submit.class.php");
$order= $DB->getRow("SELECT * FROM pre_order WHERE trade_no = '".TRADE_NO."'");
$money = $order['money'];//订单金额

//var_dump($erweima);exit;
//var_dump($make_money);exit;

foreach($erweima as $key =>$val)
{
	//echo  $val."<br>";
	//echo $order['money'].'=>'.$val[0].'<br>';
	if($order['money']  ==$val[0])
	{
			//echo "匹配成功";exit;
		$arr = [':trade_no'=>$trade_no,':url'=>$val[1],':jiage'=>$order['money'],':miyao'=>$channel['appid'],':addtime'=>strtotime($order['addtime']),'ip'=>$order['ip'],'price'=>$order['money']];
		//var_dump($arr);exit;
		
		$hba= $DB->getRow("SELECT * FROM pre_hongbao WHERE ip = '".$order['ip']."' and price=".$order['money']." and addtime >".(time()-300)." order by id desc");
		
		if($hba)
		{
			$DB->exec("update `pre_hongbao` set `trade_no` ='".$trade_no."' where `id`=".$hba['id']."");
		}
		else
		{
			$DB->exec("INSERT INTO `pre_hongbao` (`trade_no`,`url`, `jiage`,  `miyao`, `addtime`,`ip`,`price`) VALUES (:trade_no,:url, :jiage,  :miyao, :addtime,:ip,:price)", $arr);
		}
		
		
		$DB->exec("update `pre_order` set `nicheng` ='".$val[3]."' where `trade_no`='$trade_no'");
		echo "<script>window.location.href='/pay/hongbaopay/qrcode/{$trade_no}/?sitename={$sitename}';</script>";
		exit;
	}
}

	echo '请等待5分钟后再试';exit;




?>