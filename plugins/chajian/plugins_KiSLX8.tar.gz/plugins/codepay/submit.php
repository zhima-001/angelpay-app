<?php
if(!defined('IN_PLUGIN'))exit();

echo "<script>window.location.href='/pay/codepay/qrcode/{$trade_no}/?sitename={$sitename}';</script>";

