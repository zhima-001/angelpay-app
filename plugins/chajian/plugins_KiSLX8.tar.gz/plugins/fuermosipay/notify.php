<?php
if(!defined('IN_PLUGIN'))exit();
file_put_contents("./fuermosipay.txt","==========================". PHP_EOL,FILE_APPEND);
file_put_contents("./fuermosipay.txt",date("Y-m-d H:i:s")." 上游回调信息: ".json_encode($_POST). PHP_EOL,FILE_APPEND);
$mishi = $_POST['mishi'];

if($mishi == md5("aya".$order['trade_no'].'7758521')){
	//商户订单号
	$out_trade_no = daddslashes($order["trade_no"]);
	//支付宝交易号
	$trade_no = daddslashes($order["trade_no"]);
	//交易状态
	//$trade_status = $_GET['trade_status'];
	//交易金额
    //if ($_GET['trade_status'] == 'TRADE_SUCCESS') {
		//付款完成后，支付宝系统发送该交易状态通知
		
		
		$log['title'] = '收到福尔摩斯支付异步通知成功信息';//日志标题
		$log['content'] ='';//支付宝通知内容
		$log['trade_no'] = $out_trade_no;//商家订单号
		wirteLog($log);//写日志信息
		
		//if($out_trade_no == TRADE_NO && round($money,2)==round($order['money'],2) && $order['status']==0){
			if($DB->exec("update `pre_order` set `status` ='1' where `trade_no`='$out_trade_no'")){
				$DB->exec("update `pre_order` set `api_trade_no` ='$trade_no',`endtime` ='$date',`date` =NOW() where `trade_no`='$out_trade_no'");
				$DB->exec("update `pay_rand` set `status` ='1',`orderno` ='0',`url` = '0', `reorder` = '' where `orderno`='$out_trade_no'");
				file_put_contents("./fuermosipay.txt",date("Y-m-d H:i:s")." 准备处理订单信息: ".json_encode($order). PHP_EOL,FILE_APPEND);
				file_put_contents("./fuermosipay.txt","==========================". PHP_EOL,FILE_APPEND);
				processOrder($order);
			}
		//}
    //}
    //file_put_contents("./ok.txt",$money);
	echo "ok";
}else {
    //验证失败
    echo "ok";
}
?>