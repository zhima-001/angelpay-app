<?php 
	$rand= $DB->getRow("SELECT * FROM pay_rand WHERE orderno = '".TRADE_NO."' LIMIT 1");
	$djs=300-time()+$rand["time"];

$arr['djs'] = $djs;
echo json_encode($arr);
?>