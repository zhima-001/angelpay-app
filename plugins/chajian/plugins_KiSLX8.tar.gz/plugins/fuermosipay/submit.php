<?php
if(!defined('IN_PLUGIN'))exit();
include 'function.php';
//require_once(PAY_ROOT."inc/epay_submit.class.php");
$order= $DB->getRow("SELECT * FROM pre_order WHERE trade_no = '".$trade_no."'");
if($order["money"]%2!=0){
    echo "金额错误";exit;
}
if($order['money']<4)
{
	echo '最少支付4元';exit;
}


$time = time()-300;//倒计时时间5分钟。
//require_once(PAY_ROOT."inc/epay_submit.class.php");
$order= $DB->getRow("SELECT * FROM pre_order WHERE trade_no = '".TRADE_NO."'");
$money = $order['money'];//订单金额
$erweima = erweima($channel);//二维码金额
$make_money = range($money,$money-1.99,-0.01);//可支付金额（数组）
//var_dump($make_money);exit;
$ronghe = ronghe($make_money,$erweima);//两码融合
//var_dump($ronghe);exit;
//var_dump($ronghe);exit;
$pay_url = '';//二维码链接地址

foreach($ronghe as $key =>$val)
{
	$cord = cord($key,$val,$order,$time,$channel);
	if($cord == true)
	{
		$pay_url = $val['val'];
		break;
	}
}
if($pay_url =="")
{
	echo '未匹配到二维码，请稍后支付';exit;
}

echo "<script>window.location.href='/pay/fuermosipay/qrcode/{$trade_no}/?sitename={$sitename}';</script>";

?>