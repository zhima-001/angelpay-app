<?php
if(!defined('IN_PLUGIN'))exit();
	require_once(PAY_ROOT."inc/model/builder/AlipayTradeWapPayContentBuilder.php");
	require_once(PAY_ROOT."inc/AlipayTradeService.php");

	//构造参数
	$payRequestBuilder = new AlipayTradeWapPayContentBuilder();
	$payRequestBuilder->setSubject($ordername);
	$payRequestBuilder->setTotalAmount($order['money']);
	$payRequestBuilder->setOutTradeNo(TRADE_NO);

	$aop = new AlipayTradeService($config);
	
	echo $aop->wapPay($payRequestBuilder);
?>