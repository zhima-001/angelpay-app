<?php
if(!defined('IN_PLUGIN'))exit();
//file_put_contents("./taotaoing".rand(100,999).".txt",json_encode($_POST));

require_once(PAY_ROOT."inc/AlipayTradeService.php");


//计算得出通知验证结果
$alipaySevice = new AlipayTradeService($config); 
//$alipaySevice->writeLog(var_export($_POST,true));
$verify_result = $alipaySevice->check($_POST);
file_put_contents("./alipaynotify.txt","==========================". PHP_EOL,FILE_APPEND);
file_put_contents("./alipaynotify.txt",date("Y-m-d H:i:s")." 上游回调信息: ".json_encode($_POST).$verify_result. PHP_EOL,FILE_APPEND);
if($verify_result) {//验证成功
	//商户订单号

	$out_trade_no = daddslashes($_POST['out_trade_no']);

	//支付宝交易号

	$trade_no = daddslashes($_POST['trade_no']);

	//交易状态
	$trade_status = $_POST['trade_status'];

	//买家支付宝
	$buyer_id = daddslashes($_POST['buyer_id']);

	//交易金额
	$total_amount = $_POST['total_amount'];

    if ($trade_status == 'TRADE_SUCCESS') {
		//写接收到的支付宝通知信息
		$log['title'] = '收到支付宝异步通知信息';//日志标题
		$log['content'] =json_encode($_POST);;//支付宝通知内容
		$log['trade_no'] = $out_trade_no;//商家订单号
		wirteLog($log);//写日志信息
		
        file_put_contents("./alipaynotify.txt",date("Y-m-d H:i:s")." 准备处理订单信息1: ".json_encode($order).TRADE_NO. PHP_EOL,FILE_APPEND);
		if($out_trade_no == TRADE_NO && round($total_amount,2)==round($order['money'],2) && $order['status']==0){
			if($DB->exec("update `pre_order` set `status` ='1' where `trade_no`='".TRADE_NO."'")){
				$DB->exec("update `pre_order` set `api_trade_no` ='$trade_no',`endtime` ='$date',`buyer` ='$buyer_id',`date` =NOW() where `trade_no`='".TRADE_NO."'");
				file_put_contents("./alipaynotify.txt",date("Y-m-d H:i:s")." 准备处理订单信息2: ".json_encode($order). PHP_EOL,FILE_APPEND);
				file_put_contents("./alipaynotify.txt","==========================". PHP_EOL,FILE_APPEND);
				processOrder($order);
			}
		}
    }

	echo "success";
}
else {
			//写接收到的支付宝通知信息
		$log['title'] = '收到支付宝异步通知信息';//日志标题
		$log['content'] =json_encode($_POST);;//支付宝通知内容
		$log['trade_no'] = TRADE_NO;//商家订单号
		wirteLog($log);//写日志信息
    //验证失败
    echo "fail";
}
?>